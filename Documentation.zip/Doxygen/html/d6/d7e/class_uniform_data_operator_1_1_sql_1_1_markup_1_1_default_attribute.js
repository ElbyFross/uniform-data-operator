var class_uniform_data_operator_1_1_sql_1_1_markup_1_1_default_attribute =
[
    [ "DefaultAttribute", "d6/d7e/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_default_attribute.html#ab6166dcaa64b5fecb183e6d946cd94b7", null ],
    [ "defExp", "d6/d7e/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_default_attribute.html#a64185e68bab327c41b4b7424ef88677b", null ]
];