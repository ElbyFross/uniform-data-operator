var hierarchy =
[
    [ "UniformDataOperator.AssembliesManagement.AssembliesHandler", "d9/d9d/class_uniform_data_operator_1_1_assemblies_management_1_1_assemblies_handler.html", null ],
    [ "Attribute", null, [
      [ "UniformDataOperator.AssembliesManagement.Modifiers.TypeReplacer", "d8/d6c/class_uniform_data_operator_1_1_assemblies_management_1_1_modifiers_1_1_type_replacer.html", null ],
      [ "UniformDataOperator.Sql.Markup.ColumnAttribute", "d0/d68/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_column_attribute.html", null ],
      [ "UniformDataOperator.Sql.Markup.CommentaryAttribute", "d0/d7f/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_commentary_attribute.html", null ],
      [ "UniformDataOperator.Sql.Markup.DefaultAttribute", "d6/d7e/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_default_attribute.html", [
        [ "UniformDataOperator.Sql.Markup.IsGeneratedAttribute", "db/d72/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_generated_attribute.html", null ]
      ] ],
      [ "UniformDataOperator.Sql.Markup.IsAutoIncrementAttribute", "d8/dbb/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_auto_increment_attribute.html", null ],
      [ "UniformDataOperator.Sql.Markup.IsBinaryAttribute", "df/dc1/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_binary_attribute.html", null ],
      [ "UniformDataOperator.Sql.Markup.IsForeignKeyAttribute", "dd/d33/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_foreign_key_attribute.html", null ],
      [ "UniformDataOperator.Sql.Markup.IsNotNullAttribute", "d2/dbb/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_not_null_attribute.html", null ],
      [ "UniformDataOperator.Sql.Markup.IsPrimaryKeyAttribute", "d2/d28/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_primary_key_attribute.html", null ],
      [ "UniformDataOperator.Sql.Markup.IsUniqueAttribute", "d0/d27/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_unique_attribute.html", null ],
      [ "UniformDataOperator.Sql.Markup.IsUnsignedAttribute", "d6/d2f/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_unsigned_attribute.html", null ],
      [ "UniformDataOperator.Sql.Markup.IsZeroFillAttribute", "d1/d7c/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_zero_fill_attribute.html", null ],
      [ "UniformDataOperator.Sql.Markup.Modifiers.DBPathOverrideAttribute", "d0/d9c/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_modifiers_1_1_d_b_path_override_attribute.html", null ],
      [ "UniformDataOperator.Sql.Markup.Modifiers.SetQueryIgnoreAttribute", "db/d05/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_modifiers_1_1_set_query_ignore_attribute.html", null ],
      [ "UniformDataOperator.Sql.Markup.TableAttribute", "d3/d61/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_table_attribute.html", null ],
      [ "UniformDataOperator.Sql.MySql.Markup.MySqlDBTypeOverrideAttribute", "da/d96/class_uniform_data_operator_1_1_sql_1_1_my_sql_1_1_markup_1_1_my_sql_d_b_type_override_attribute.html", null ]
    ] ],
    [ "UniformDataOperator.Binary.BinaryHandler", "d5/dc1/class_uniform_data_operator_1_1_binary_1_1_binary_handler.html", null ],
    [ "UniformDataOperator.Binary.BoyerMoore", "da/d1e/class_uniform_data_operator_1_1_binary_1_1_boyer_moore.html", null ],
    [ "UniformDataOperator.AssembliesManagement.Modifiers.IBaseTypeChangable", "d3/d31/interface_uniform_data_operator_1_1_assemblies_management_1_1_modifiers_1_1_i_base_type_changable.html", null ],
    [ "UniformDataOperator.Sql.ISqlOperator", "d1/dad/interface_uniform_data_operator_1_1_sql_1_1_i_sql_operator.html", [
      [ "UniformDataOperator.Sql.MySql.MySqlDataOperator", "d5/d34/class_uniform_data_operator_1_1_sql_1_1_my_sql_1_1_my_sql_data_operator.html", null ],
      [ "UniformDataOperator.Sql.MySql.MySqlDataOperator", "d5/d34/class_uniform_data_operator_1_1_sql_1_1_my_sql_1_1_my_sql_data_operator.html", null ],
      [ "UniformDataOperator.Sql.MySql.MySqlDataOperator", "d5/d34/class_uniform_data_operator_1_1_sql_1_1_my_sql_1_1_my_sql_data_operator.html", null ],
      [ "UniformDataOperator.Sql.MySql.MySqlDataOperator", "d5/d34/class_uniform_data_operator_1_1_sql_1_1_my_sql_1_1_my_sql_data_operator.html", null ],
      [ "UniformDataOperator.Sql.MySql.MySqlDataOperator", "d5/d34/class_uniform_data_operator_1_1_sql_1_1_my_sql_1_1_my_sql_data_operator.html", null ],
      [ "UniformDataOperator.Sql.MySql.MySqlDataOperator", "d5/d34/class_uniform_data_operator_1_1_sql_1_1_my_sql_1_1_my_sql_data_operator.html", null ]
    ] ],
    [ "UniformDataOperator.AssembliesManagement.MembersHandler", "d5/d10/class_uniform_data_operator_1_1_assemblies_management_1_1_members_handler.html", null ],
    [ "UniformDataOperator.AssembliesManagement.Modifiers.TypeReplacer.ReplacingMeta", "dd/d32/class_uniform_data_operator_1_1_assemblies_management_1_1_modifiers_1_1_type_replacer_1_1_replacing_meta.html", null ],
    [ "UniformDataOperator.AssembliesManagement.MembersHandler.RuntimeAttributeInfo", "d6/d56/struct_uniform_data_operator_1_1_assemblies_management_1_1_members_handler_1_1_runtime_attribute_info.html", null ],
    [ "UniformDataOperator.Sql.SqlOperatorHandler", "dc/dce/class_uniform_data_operator_1_1_sql_1_1_sql_operator_handler.html", null ],
    [ "UniformDataOperator.Binary.IO.StreamHandler", "d9/d47/class_uniform_data_operator_1_1_binary_1_1_i_o_1_1_stream_handler.html", null ]
];