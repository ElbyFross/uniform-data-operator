var class_uniform_data_operator_1_1_sql_1_1_markup_1_1_commentary_attribute =
[
    [ "CommentaryAttribute", "d0/d7f/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_commentary_attribute.html#a89e4ce7ba19efd0b533ef9a5d013658d", null ],
    [ "operator string", "d0/d7f/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_commentary_attribute.html#a7bf4b9cbf59270e66700f7c2468ccb00", null ],
    [ "ToString", "d0/d7f/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_commentary_attribute.html#a90440c0a6947fd524fef872cdb7c7683", null ],
    [ "commentary", "d0/d7f/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_commentary_attribute.html#a729a7d6773b3df9dd31090b1cf8e35b1", null ]
];