var searchData=
[
  ['userid',['UserId',['../d1/dad/interface_uniform_data_operator_1_1_sql_1_1_i_sql_operator.html#abf0c3a32c8161030b37ccf960c395d4f',1,'UniformDataOperator.Sql.ISqlOperator.UserId()'],['../d5/d34/class_uniform_data_operator_1_1_sql_1_1_my_sql_1_1_my_sql_data_operator.html#ae5e119508a6d9807b9e138c628a6e18f',1,'UniformDataOperator.Sql.MySql.MySqlDataOperator.UserId()']]]
];
