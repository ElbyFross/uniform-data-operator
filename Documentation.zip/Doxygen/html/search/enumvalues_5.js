var searchData=
[
  ['setnull',['SetNull',['../dd/d33/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_foreign_key_attribute.html#ae6c77deaf80d5c4d07709edf51eaebc5a2ac481dd701d4f580b6b01eb34442e71',1,'UniformDataOperator::Sql::Markup::IsForeignKeyAttribute']]],
  ['stored',['Stored',['../db/d72/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_generated_attribute.html#a03e5e76ff63dbcf2cca5746e3098b23da7bf2d26eab899c413218b729d4d914b7',1,'UniformDataOperator::Sql::Markup::IsGeneratedAttribute']]]
];
