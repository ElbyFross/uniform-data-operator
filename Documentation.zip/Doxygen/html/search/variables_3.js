var searchData=
[
  ['header_5fsize',['HEADER_SIZE',['../d9/d47/class_uniform_data_operator_1_1_binary_1_1_i_o_1_1_stream_handler.html#a74670b4bc43b03cbfcb5f222fe731da0',1,'UniformDataOperator::Binary::IO::StreamHandler']]]
];
