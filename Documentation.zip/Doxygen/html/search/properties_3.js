var searchData=
[
  ['milisecondsbeforedrop',['MilisecondsBeforeDrop',['../d9/d47/class_uniform_data_operator_1_1_binary_1_1_i_o_1_1_stream_handler.html#a9f8d84e7fcc7106e4dfed14d7f574b87',1,'UniformDataOperator::Binary::IO::StreamHandler']]]
];
