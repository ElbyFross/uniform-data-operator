var searchData=
[
  ['openconnection',['OpenConnection',['../d1/dad/interface_uniform_data_operator_1_1_sql_1_1_i_sql_operator.html#a6fc9e5efd1e21ae9998b9c56ae9e347c',1,'UniformDataOperator.Sql.ISqlOperator.OpenConnection()'],['../d5/d34/class_uniform_data_operator_1_1_sql_1_1_my_sql_1_1_my_sql_data_operator.html#ae7ad4f4d29d927fa8551b087a6e596b5',1,'UniformDataOperator.Sql.MySql.MySqlDataOperator.OpenConnection()']]],
  ['operatetype',['OperateType',['../d8/d6c/class_uniform_data_operator_1_1_assemblies_management_1_1_modifiers_1_1_type_replacer.html#a51670e843f80ee62f24afa784d5424dc',1,'UniformDataOperator::AssembliesManagement::Modifiers::TypeReplacer']]],
  ['operator_20string',['operator string',['../d0/d68/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_column_attribute.html#a4dbbb1a9e3623b25d66ba2778b9c35d9',1,'UniformDataOperator.Sql.Markup.ColumnAttribute.operator string()'],['../d0/d7f/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_commentary_attribute.html#a7bf4b9cbf59270e66700f7c2468ccb00',1,'UniformDataOperator.Sql.Markup.CommentaryAttribute.operator string()']]]
];
