var searchData=
[
  ['noaction',['NoAction',['../dd/d33/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_foreign_key_attribute.html#ae6c77deaf80d5c4d07709edf51eaebc5a1e601ea653db1c729c9ee5746730fabe',1,'UniformDataOperator::Sql::Markup::IsForeignKeyAttribute']]]
];
