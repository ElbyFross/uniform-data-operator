var searchData=
[
  ['restrict',['Restrict',['../dd/d33/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_foreign_key_attribute.html#ae6c77deaf80d5c4d07709edf51eaebc5a034d70b46e41ec9d0306b0001e04cae7',1,'UniformDataOperator::Sql::Markup::IsForeignKeyAttribute']]]
];
