var searchData=
[
  ['actiontocommand',['ActionToCommand',['../dd/d33/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_foreign_key_attribute.html#adaff7734b94478d0b37cc8659a0c2acd',1,'UniformDataOperator::Sql::Markup::IsForeignKeyAttribute']]],
  ['activateschema',['ActivateSchema',['../d1/dad/interface_uniform_data_operator_1_1_sql_1_1_i_sql_operator.html#a5ae8328a464ef80f1ae1bd46a573c265',1,'UniformDataOperator.Sql.ISqlOperator.ActivateSchema()'],['../d5/d34/class_uniform_data_operator_1_1_sql_1_1_my_sql_1_1_my_sql_data_operator.html#a2ed7d06bc016ae6d07cbcceffc21bbd3',1,'UniformDataOperator.Sql.MySql.MySqlDataOperator.ActivateSchema()']]],
  ['addattribute',['AddAttribute',['../d5/d10/class_uniform_data_operator_1_1_assemblies_management_1_1_members_handler.html#a66f0295fa016e2d296046fd968103a4e',1,'UniformDataOperator::AssembliesManagement::MembersHandler']]]
];
