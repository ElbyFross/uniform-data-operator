var searchData=
[
  ['database',['Database',['../d1/dad/interface_uniform_data_operator_1_1_sql_1_1_i_sql_operator.html#a55b7f28ed4ab20f124e67e2d447f8b40',1,'UniformDataOperator.Sql.ISqlOperator.Database()'],['../d5/d34/class_uniform_data_operator_1_1_sql_1_1_my_sql_1_1_my_sql_data_operator.html#a144616e12acb2b55c7046af0c9af989d',1,'UniformDataOperator.Sql.MySql.MySqlDataOperator.Database()']]]
];
