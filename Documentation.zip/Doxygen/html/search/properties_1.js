var searchData=
[
  ['connection',['Connection',['../d1/dad/interface_uniform_data_operator_1_1_sql_1_1_i_sql_operator.html#a99f034a986828e96955e3187cdfb28da',1,'UniformDataOperator.Sql.ISqlOperator.Connection()'],['../d5/d34/class_uniform_data_operator_1_1_sql_1_1_my_sql_1_1_my_sql_data_operator.html#a5c5d34c3f7b7d95773ba44ede46409a0',1,'UniformDataOperator.Sql.MySql.MySqlDataOperator.Connection()']]]
];
