var searchData=
[
  ['duplex',['Duplex',['../d3/d2f/namespace_uniform_data_operator_1_1_binary_1_1_i_o.html#a3fee9a9bcba25974554ed63395942161acfefe70df0902a80bb48b04ff12a7436',1,'UniformDataOperator::Binary::IO']]]
];
