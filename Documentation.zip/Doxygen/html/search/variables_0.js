var searchData=
[
  ['column',['column',['../dd/d33/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_foreign_key_attribute.html#aa305b69f1eac8e7335b9776b5d30625e',1,'UniformDataOperator.Sql.Markup.IsForeignKeyAttribute.column()'],['../d0/d9c/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_modifiers_1_1_d_b_path_override_attribute.html#a30bd9209a06db42db371c857573af3be',1,'UniformDataOperator.Sql.Markup.Modifiers.DBPathOverrideAttribute.column()']]],
  ['commentary',['commentary',['../d0/d7f/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_commentary_attribute.html#a729a7d6773b3df9dd31090b1cf8e35b1',1,'UniformDataOperator::Sql::Markup::CommentaryAttribute']]],
  ['connection',['connection',['../d5/d34/class_uniform_data_operator_1_1_sql_1_1_my_sql_1_1_my_sql_data_operator.html#a807f034631cd8284ecc020d765e6f6f1',1,'UniformDataOperator::Sql::MySql::MySqlDataOperator']]]
];
