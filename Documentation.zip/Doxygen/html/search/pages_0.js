var searchData=
[
  ['uniform_20data_20operator',['Uniform Data Operator',['../d4/d04/md__d_1__work__git_hub_uniform-data-operator__r_e_a_d_m_e.html',1,'']]]
];
