var searchData=
[
  ['backup',['Backup',['../d1/dad/interface_uniform_data_operator_1_1_sql_1_1_i_sql_operator.html#a096be4f746c1fcbb8b2894c2517b937c',1,'UniformDataOperator.Sql.ISqlOperator.Backup()'],['../d5/d34/class_uniform_data_operator_1_1_sql_1_1_my_sql_1_1_my_sql_data_operator.html#a0dbd58206733a17dd26143b58d0859d7',1,'UniformDataOperator.Sql.MySql.MySqlDataOperator.Backup()']]],
  ['binaryhandler',['BinaryHandler',['../d5/dc1/class_uniform_data_operator_1_1_binary_1_1_binary_handler.html',1,'UniformDataOperator::Binary']]],
  ['boyermoore',['BoyerMoore',['../da/d1e/class_uniform_data_operator_1_1_binary_1_1_boyer_moore.html',1,'UniformDataOperator::Binary']]],
  ['buildpackage',['BuildPackage',['../d9/d47/class_uniform_data_operator_1_1_binary_1_1_i_o_1_1_stream_handler.html#ac3b951b7af74e35d8c01f9986d59abbf',1,'UniformDataOperator::Binary::IO::StreamHandler']]]
];
