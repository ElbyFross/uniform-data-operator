var searchData=
[
  ['setqueryignoreattribute',['SetQueryIgnoreAttribute',['../db/d05/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_modifiers_1_1_set_query_ignore_attribute.html',1,'UniformDataOperator::Sql::Markup::Modifiers']]],
  ['sqloperatorhandler',['SqlOperatorHandler',['../dc/dce/class_uniform_data_operator_1_1_sql_1_1_sql_operator_handler.html',1,'UniformDataOperator::Sql']]],
  ['streamhandler',['StreamHandler',['../d9/d47/class_uniform_data_operator_1_1_binary_1_1_i_o_1_1_stream_handler.html',1,'UniformDataOperator::Binary::IO']]]
];
