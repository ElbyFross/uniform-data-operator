var searchData=
[
  ['binaryhandler',['BinaryHandler',['../d5/dc1/class_uniform_data_operator_1_1_binary_1_1_binary_handler.html',1,'UniformDataOperator::Binary']]],
  ['boyermoore',['BoyerMoore',['../da/d1e/class_uniform_data_operator_1_1_binary_1_1_boyer_moore.html',1,'UniformDataOperator::Binary']]]
];
