var searchData=
[
  ['columnattribute',['ColumnAttribute',['../d0/d68/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_column_attribute.html',1,'UniformDataOperator::Sql::Markup']]],
  ['commentaryattribute',['CommentaryAttribute',['../d0/d7f/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_commentary_attribute.html',1,'UniformDataOperator::Sql::Markup']]]
];
