var searchData=
[
  ['server',['Server',['../d1/dad/interface_uniform_data_operator_1_1_sql_1_1_i_sql_operator.html#ab1b593e38cb9377dac847811c483f2f3',1,'UniformDataOperator.Sql.ISqlOperator.Server()'],['../d5/d34/class_uniform_data_operator_1_1_sql_1_1_my_sql_1_1_my_sql_data_operator.html#a2154fef9e522ef26cf08642483fed223',1,'UniformDataOperator.Sql.MySql.MySqlDataOperator.Server()']]]
];
