var class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_generated_attribute =
[
    [ "Mode", "db/d72/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_generated_attribute.html#a03e5e76ff63dbcf2cca5746e3098b23d", [
      [ "Stored", "db/d72/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_generated_attribute.html#a03e5e76ff63dbcf2cca5746e3098b23da7bf2d26eab899c413218b729d4d914b7", null ],
      [ "Virual", "db/d72/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_generated_attribute.html#a03e5e76ff63dbcf2cca5746e3098b23daa6d194ab7efe0417c28a02b8a8997bd0", null ]
    ] ],
    [ "IsGeneratedAttribute", "db/d72/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_generated_attribute.html#a03bea379c3a0e0694e9a29eba9b11797", null ],
    [ "mode", "db/d72/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_is_generated_attribute.html#a026c142857b7314d18d3031c76a74c41", null ]
];