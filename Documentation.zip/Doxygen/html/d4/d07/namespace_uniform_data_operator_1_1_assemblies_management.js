var namespace_uniform_data_operator_1_1_assemblies_management =
[
    [ "Modifiers", "d8/dd0/namespace_uniform_data_operator_1_1_assemblies_management_1_1_modifiers.html", "d8/dd0/namespace_uniform_data_operator_1_1_assemblies_management_1_1_modifiers" ],
    [ "AssembliesHandler", "d9/d9d/class_uniform_data_operator_1_1_assemblies_management_1_1_assemblies_handler.html", "d9/d9d/class_uniform_data_operator_1_1_assemblies_management_1_1_assemblies_handler" ],
    [ "MembersHandler", "d5/d10/class_uniform_data_operator_1_1_assemblies_management_1_1_members_handler.html", "d5/d10/class_uniform_data_operator_1_1_assemblies_management_1_1_members_handler" ]
];