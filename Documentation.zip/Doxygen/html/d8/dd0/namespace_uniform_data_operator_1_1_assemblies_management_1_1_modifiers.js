var namespace_uniform_data_operator_1_1_assemblies_management_1_1_modifiers =
[
    [ "IBaseTypeChangable", "d3/d31/interface_uniform_data_operator_1_1_assemblies_management_1_1_modifiers_1_1_i_base_type_changable.html", "d3/d31/interface_uniform_data_operator_1_1_assemblies_management_1_1_modifiers_1_1_i_base_type_changable" ],
    [ "TypeReplacer", "d8/d6c/class_uniform_data_operator_1_1_assemblies_management_1_1_modifiers_1_1_type_replacer.html", "d8/d6c/class_uniform_data_operator_1_1_assemblies_management_1_1_modifiers_1_1_type_replacer" ]
];