var namespace_uniform_data_operator_1_1_sql =
[
    [ "Markup", "de/d8b/namespace_uniform_data_operator_1_1_sql_1_1_markup.html", "de/d8b/namespace_uniform_data_operator_1_1_sql_1_1_markup" ],
    [ "MySql", "d1/d09/namespace_uniform_data_operator_1_1_sql_1_1_my_sql.html", "d1/d09/namespace_uniform_data_operator_1_1_sql_1_1_my_sql" ],
    [ "ISqlOperator", "d1/dad/interface_uniform_data_operator_1_1_sql_1_1_i_sql_operator.html", "d1/dad/interface_uniform_data_operator_1_1_sql_1_1_i_sql_operator" ],
    [ "SqlOperatorHandler", "dc/dce/class_uniform_data_operator_1_1_sql_1_1_sql_operator_handler.html", "dc/dce/class_uniform_data_operator_1_1_sql_1_1_sql_operator_handler" ]
];