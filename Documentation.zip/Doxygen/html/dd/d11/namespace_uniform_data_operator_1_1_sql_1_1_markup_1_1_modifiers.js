var namespace_uniform_data_operator_1_1_sql_1_1_markup_1_1_modifiers =
[
    [ "DBPathOverrideAttribute", "d0/d9c/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_modifiers_1_1_d_b_path_override_attribute.html", "d0/d9c/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_modifiers_1_1_d_b_path_override_attribute" ],
    [ "SetQueryIgnoreAttribute", "db/d05/class_uniform_data_operator_1_1_sql_1_1_markup_1_1_modifiers_1_1_set_query_ignore_attribute.html", null ]
];